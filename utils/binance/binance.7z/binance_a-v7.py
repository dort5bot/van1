# utils/binance/binance_a.py
"""
v7
Aggregator for Binance API (Public + Private).
- Async / await
- Aiogram 3.x Router uyumlu
- Singleton pattern
- PEP8 + logging
"""

import logging
from typing import Optional, Dict, Any

# Public imports
from . import binance_pb_spot, binance_pb_futures, binance_pb_system, binance_pb_index

# Private imports
from .binance_pr_spot import SpotClient
from .binance_pr_futures import FuturesClient
from .binance_pr_margin import MarginClient
from .binance_pr_asset import AssetClient
from .binance_pr_savings import SavingsClient
from .binance_pr_staking import StakingClient
from .binance_pr_mining import MiningClient
from .binance_pr_subaccount import SubAccountClient
from .binance_pr_userstream import UserStreamClient
from .binance_pr_base import BinancePrivateBase

# Common imports
#from .binance_request import BinanceRequest, BinanceHTTPClient
from .binance_request import BinanceHTTPClient
from .binance_circuit_breaker import CircuitBreaker
from ..apikey_manager import APIKeyManager

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class AggregatorSettings:
    """Common configuration for Binance API aggregator."""
    _instance: Optional["AggregatorSettings"] = None

    def __init__(self, default_user: Optional[int] = None):
        self.default_user = default_user
        self.request = BinanceRequest.get_instance()
        self.apikey_db = APIKeyManager.get_instance()
        self.circuit_breaker = CircuitBreaker()

    @classmethod
    def get_instance(cls) -> "AggregatorSettings":
        if cls._instance is None:
            cls._instance = AggregatorSettings()
        return cls._instance

    async def build_private_client(self, user_id: Optional[int] = None) -> BinancePrivateBase:
        """Factory: build a private API base client with user's keys."""
        creds = await self.apikey_db.get_apikey(user_id or self.default_user)
        if not creds:
            raise ValueError("No API key found for user")
        api_key, api_secret = creds
        http_client = BinanceHTTPClient(api_key=api_key, secret_key=api_secret)
        return BinancePrivateBase(http_client, self.circuit_breaker)


# ===============================
# PUBLIC API
# ===============================
class PublicApi:
    """Group Binance Public API calls."""

    class PublicSpot:
        @staticmethod
        async def get_klines(symbol: str, interval: str, limit: int = 500) -> Any:
            return await binance_pb_spot.get_klines(symbol=symbol, interval=interval, limit=limit)

        @staticmethod
        async def get_ticker_price(symbol: str) -> Dict[str, Any]:
            return await binance_pb_spot.get_ticker_price(symbol)

    class PublicFutures:
        @staticmethod
        async def get_futures_klines(symbol: str, interval: str, limit: int = 500) -> Any:
            return await binance_pb_futures.get_klines(symbol=symbol, interval=interval, limit=limit)

        @staticmethod
        async def get_mark_price(symbol: str) -> Dict[str, Any]:
            return await binance_pb_futures.get_mark_price(symbol)

    class PublicSystem:
        @staticmethod
        async def ping() -> bool:
            return await binance_pb_system.ping()

        @staticmethod
        async def get_exchange_info() -> Dict[str, Any]:
            return await binance_pb_system.get_exchange_info()

    class PublicIndex:
        @staticmethod
        async def get_index_price(symbol: str) -> Dict[str, Any]:
            return await binance_pb_index.get_index_price(symbol)


# ===============================
# PRIVATE API
# ===============================
class PrivateApi:
    """Group Binance Private API calls (requires API Key)."""

    class PrivateSpot:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> SpotClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return SpotClient(base.http, base.circuit_breaker)

    class PrivateFutures:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> FuturesClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return FuturesClient(base.http, base.circuit_breaker)

    class PrivateMargin:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> MarginClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return MarginClient(base.http, base.circuit_breaker)

    class PrivateAsset:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> AssetClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return AssetClient(base.http, base.circuit_breaker)

    class PrivateSavings:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> SavingsClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return SavingsClient(base.http, base.circuit_breaker)

    class PrivateStaking:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> StakingClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return StakingClient(base.http, base.circuit_breaker)

    class PrivateMining:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> MiningClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return MiningClient(base.http, base.circuit_breaker)

    class PrivateSubAccount:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> SubAccountClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return SubAccountClient(base.http, base.circuit_breaker)

    class PrivateUserStream:
        @staticmethod
        async def client(user_id: Optional[int] = None) -> UserStreamClient:
            settings = AggregatorSettings.get_instance()
            base = await settings.build_private_client(user_id)
            return UserStreamClient(base.http, base.circuit_breaker)


# ===============================
# MAIN AGGREGATOR
# ===============================
class BinanceAggregator:
    """Unified Binance Aggregator for Public + Private APIs (async singleton)."""

    _instance: Optional["BinanceAggregator"] = None

    def __init__(self):
        self.public = PublicApi()
        self.private = PrivateApi()
        logger.info("✅ BinanceAggregator initialized")

    @classmethod
    def get_instance(cls) -> "BinanceAggregator":
        if cls._instance is None:
            cls._instance = BinanceAggregator()
        return cls._instance
